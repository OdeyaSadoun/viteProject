import React from 'react'

const Home = () => {
  return (
    <h2 className='text-danger h3'>Hello</h2>
  )
}

export default Home